ASIA BIOMED INNOVATION — YANGILANGAN SAYT FAYLLARI

Tarkibi:
- index.html      — Bosh sahifa
- about.html      — Biz haqimizda
- products.html   — Mahsulotlar
- partners.html   — Hamkorlarimiz
- documents.html  — Hujjatlar
- contact.html    — Aloqa va hamkorlik taklifi
- assets/css/style.css — Dizayn va telefon ekraniga moslashuv
- assets/js/main.js    — Til tanlash va forma funksiyasi

Tillar: O‘zbek, rus, ingliz va xitoy. Til tanlagichi ishlaydi; tanlangan til brauzerda saqlanadi. Bosh sahifa va footer matnlari tarjima qilinadi.

MUHIM:
1. Bu yangilangan frontend fayllari. Hozirgi Netlify saytingizga hali joylashtirilmagan.
2. Saytni joylashtirishdan oldin Netlify’dagi eski fayllarni zaxiralang.
3. Aloqa formasining demo versiyasi foydalanuvchining email dasturini ochadi. U avtomatik serverga murojaatlarni saqlamaydi. Avtomatik saqlash va email yuborish uchun backend/form service sozlanishi kerak.
4. Telegram username/link tasdiqlanmagani uchun Telegram tugmasi qo‘shilmadi.
5. Mahsulotlar, hamkorlar va hujjatlar bo‘limlarida ma’lumotlar tasdiqlanmaguncha bo‘sh holat ko‘rsatiladi; soxta mahsulot yoki hamkor nomlari kiritilmagan.

Netlify’ga joylash: ZIP ichidagi fayllarni ochib, index.html fayli ZIP ichining yuqori qatlamida turganini tekshiring. Netlify deploy usuliga qarab sayt papkasini yoki fayllarni deploy qiling. Eski saytni almashtirishdan oldin backup oling.
