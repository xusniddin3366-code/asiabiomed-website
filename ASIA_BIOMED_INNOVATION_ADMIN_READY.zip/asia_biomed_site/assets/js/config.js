// Site configuration. Replace Telegram URL only after confirming the company's public Telegram username/link.
window.ABI_CONFIG={phone:'+998 90 858-33-66',email:'xusniddin@gmail.com',whatsapp:'https://wa.me/998908583366',telegram:'https://t.me/'};
